A3W extDB2 MySQL instructions

1. Extract everything from this folder to your Arma 3 install dir
2. Run the a3wasteland db SQL script with your MySQL tool of choice
3. Open extdb-conf.ini and put your MySQL connection infos in the [A3W] section
4. Try to start your server, and hope it doesn't blow in your face

That should do it!

If you want to create a MySQL user with restricted access just for extDB, the privileges needed are: INSERT, SELECT, UPDATE, DELETE

A3Wasteland v1.2 is currently compatible with extDB2 v49 and up.

For Linux, you need to install libtbb2 too:
https://github.com/Torndeco/extDB2/wiki/Setup:-Linux-Static-Build
