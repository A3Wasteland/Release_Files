A3W extDB MySQL beta instructions

1. Extract everything from this ZIP to your Arma 3 install dir
2. Run the a3wasteland db SQL script on your MySQL database
3. Open extdb-conf.ini and put your MySQL connection infos in the [A3W] section
4. Try to start your server, and hope it doesn't blow in your face

That should do it!

A3Wasteland is currently compatible with extDB v21, 25, 26, and 27.


For Linux, this is the file you will need instead of the DLLs:
https://github.com/Torndeco/extdb/raw/3bfe009bb151fbe7416628a1afa4f84cdbdce487/Release/linux/27/%40extDB/extDB.so

And you need to install libtbb2 too:
https://github.com/Torndeco/extdb/wiki/Setup:-Linux-Static-Build
