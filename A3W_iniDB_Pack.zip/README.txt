How to setup saving:

1. Extract the contents of this ZIP to your Arma 3 folder

That's it!

You can customize what can be saved by opening A3Wasteland_settings\main_config.sqf
with a text editor like Notepad, and looking under the "Persistence settings" section.
