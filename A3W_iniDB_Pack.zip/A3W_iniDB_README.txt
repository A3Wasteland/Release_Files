A3W iniDB instructions

 1. Extract the contents from this archive to your Arma 3 root directory, where arma3server is normally located
 2. Add -filePatching to your arma3server command line, and allowedFilePatching = 1; to your server.cfg
 3. If you have a headless client, add -filePatching to your arma3server headless command line

That's it!

You can customize what can be saved by opening A3Wasteland_settings\main_config.sqf
with a text editor like Notepad, and looking under the "Persistence settings" section.
