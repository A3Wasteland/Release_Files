How to setup persistence:

1. Extract the contents of this ZIP to your Arma 3 folder

That's it!

You can customize what can be saved by opening A3Wasteland_settings\main_config.sqf
with a text editor like Notepad, and looking under the "Persistence settings" section.

If saving refuses to work, try installing the following on your server:
http://www.microsoft.com/download/details.aspx?id=8328
